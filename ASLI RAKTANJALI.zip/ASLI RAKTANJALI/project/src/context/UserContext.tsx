import React, { createContext, useState, useContext, ReactNode } from 'react';

type UserType = 'donor' | 'recipient' | null;

interface UserContextType {
  userType: UserType;
  isLoggedIn: boolean;
  userData: UserData | null;
  setUserType: (type: UserType) => void;
  login: (data: UserData) => void;
  logout: () => void;
}

interface UserData {
  id: string;
  name: string;
  email: string;
  bloodType?: string;
  state?: string;
  city?: string;
  pincode?: string;
  phone?: string;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider = ({ children }: { children: ReactNode }) => {
  const [userType, setUserType] = useState<UserType>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userData, setUserData] = useState<UserData | null>(null);

  const login = (data: UserData) => {
    setUserData(data);
    setIsLoggedIn(true);
  };

  const logout = () => {
    setUserData(null);
    setIsLoggedIn(false);
    setUserType(null);
  };

  return (
    <UserContext.Provider
      value={{
        userType,
        isLoggedIn,
        userData,
        setUserType,
        login,
        logout,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};