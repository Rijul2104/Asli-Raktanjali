import React from 'react';
import { Heart, Mail, Phone, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* About */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Raktanjali</h3>
            <p className="text-gray-300 mb-4">
              Connecting blood donors with recipients across India. A noble initiative by AISSMS AIDS BOYS to save lives through blood donation.
            </p>
            <div className="flex items-center">
              <Heart className="text-red-500 mr-2" size={20} />
              <span>Every drop counts</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-300 hover:text-red-400 transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/find-donors" className="text-gray-300 hover:text-red-400 transition-colors">Find Donors</Link>
              </li>
              <li>
                <Link to="/request-blood" className="text-gray-300 hover:text-red-400 transition-colors">Request Blood</Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-300 hover:text-red-400 transition-colors">About Us</Link>
              </li>
              <li>
                <Link to="/register" className="text-gray-300 hover:text-red-400 transition-colors">Register</Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="mr-2 text-red-400 flex-shrink-0 mt-1" size={18} />
                <span className="text-gray-300">AISSMS College, Kennedy Road, Near RTO, Pune, Maharashtra - 411001</span>
              </li>
              <li className="flex items-center">
                <Phone className="mr-2 text-red-400" size={18} />
                <span className="text-gray-300">+91 1234567890</span>
              </li>
              <li className="flex items-center">
                <Mail className="mr-2 text-red-400" size={18} />
                <span className="text-gray-300">info@raktanjali.org</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-700 pt-6 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} Raktanjali. All rights reserved. An initiative by AISSMS AIDS BOYS.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;