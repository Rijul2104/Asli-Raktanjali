import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, User, Droplet as DropletHalf } from 'lucide-react';
import { useUser } from '../../context/UserContext';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { isLoggedIn, userType, logout } = useUser();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2">
            <DropletHalf size={28} className="text-red-600" />
            <span className="text-2xl font-serif font-bold text-red-600">Raktanjali</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="nav-link">Home</Link>
            <Link to="/find-donors" className="nav-link">Find Donors</Link>
            <Link to="/request-blood" className="nav-link">Request Blood</Link>
            <Link to="/about" className="nav-link">About Us</Link>
            
            {isLoggedIn ? (
              <div className="flex items-center space-x-4">
                <Link 
                  to={userType === 'donor' ? '/donor-dashboard' : '/recipient-dashboard'} 
                  className="flex items-center space-x-2 text-gray-700 hover:text-red-600 transition-colors"
                >
                  <User size={20} />
                  <span>Dashboard</span>
                </Link>
                <button 
                  onClick={logout}
                  className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
                >
                  Logout
                </button>
              </div>
            ) : (
              <Link 
                to="/register" 
                className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
              >
                Register / Login
              </Link>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-700 hover:text-red-600 transition-colors"
            onClick={toggleMenu}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 space-y-3">
            <Link to="/" className="mobile-nav-link">Home</Link>
            <Link to="/find-donors" className="mobile-nav-link">Find Donors</Link>
            <Link to="/request-blood" className="mobile-nav-link">Request Blood</Link>
            <Link to="/about" className="mobile-nav-link">About Us</Link>
            
            {isLoggedIn ? (
              <>
                <Link 
                  to={userType === 'donor' ? '/donor-dashboard' : '/recipient-dashboard'} 
                  className="mobile-nav-link"
                >
                  Dashboard
                </Link>
                <button 
                  onClick={logout}
                  className="w-full text-left py-2 text-red-600 font-medium"
                >
                  Logout
                </button>
              </>
            ) : (
              <Link 
                to="/register" 
                className="block w-full text-center px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
              >
                Register / Login
              </Link>
            )}
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;