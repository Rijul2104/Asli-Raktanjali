import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../context/UserContext';
import { states } from '../data/states';
import { User, Droplet as DropletHalf } from 'lucide-react';

const Register: React.FC = () => {
  const navigate = useNavigate();
  const { setUserType, login } = useUser();

  const [activeTab, setActiveTab] = useState<'login' | 'register'>('register');
  const [userRole, setUserRole] = useState<'donor' | 'recipient'>('donor');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    bloodType: '',
    state: '',
    city: '',
    pincode: '',
    agreeToTerms: false,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    });
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name) newErrors.name = 'Name is required';
    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
    }
    
    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }
    
    if (!formData.phone) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\d{10}$/.test(formData.phone)) {
      newErrors.phone = 'Phone number must be 10 digits';
    }
    
    if (userRole === 'donor' && !formData.bloodType) {
      newErrors.bloodType = 'Blood type is required';
    }
    
    if (!formData.state) newErrors.state = 'State is required';
    if (!formData.city) newErrors.city = 'City is required';
    if (!formData.pincode) {
      newErrors.pincode = 'Pincode is required';
    } else if (!/^\d{6}$/.test(formData.pincode)) {
      newErrors.pincode = 'Pincode must be 6 digits';
    }
    
    if (!formData.agreeToTerms) {
      newErrors.agreeToTerms = 'You must agree to the terms and conditions';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate login (would connect to backend API in real app)
    login({
      id: '123',
      name: formData.name || 'User',
      email: formData.email,
    });
    setUserType(userRole);
    navigate(userRole === 'donor' ? '/donor-dashboard' : '/recipient-dashboard');
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    // Simulate registration (would connect to backend API in real app)
    login({
      id: '123',
      name: formData.name,
      email: formData.email,
      bloodType: formData.bloodType,
      state: formData.state,
      city: formData.city,
      pincode: formData.pincode,
      phone: formData.phone,
    });
    setUserType(userRole);
    navigate(userRole === 'donor' ? '/donor-dashboard' : '/recipient-dashboard');
  };

  return (
    <div className="py-12 bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4">
        <div className="max-w-xl mx-auto bg-white shadow-lg rounded-lg overflow-hidden">
          {/* Tabs */}
          <div className="flex">
            <button
              className={`flex-1 py-4 text-center font-medium transition-colors ${
                activeTab === 'register'
                  ? 'bg-red-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
              onClick={() => setActiveTab('register')}
            >
              Register
            </button>
            <button
              className={`flex-1 py-4 text-center font-medium transition-colors ${
                activeTab === 'login'
                  ? 'bg-red-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
              onClick={() => setActiveTab('login')}
            >
              Login
            </button>
          </div>

          <div className="p-8">
            {activeTab === 'register' ? (
              // Register Form
              <form onSubmit={handleRegisterSubmit}>
                <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">
                  Join Raktanjali
                </h2>

                {/* User Type Selection */}
                <div className="mb-6">
                  <label className="block text-gray-700 mb-2">I want to:</label>
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      type="button"
                      className={`flex items-center justify-center p-4 border rounded-lg transition-colors ${
                        userRole === 'donor'
                          ? 'border-red-500 bg-red-50 text-red-700'
                          : 'border-gray-300 hover:bg-gray-50'
                      }`}
                      onClick={() => setUserRole('donor')}
                    >
                      <DropletHalf size={20} className="mr-2" />
                      Donate Blood
                    </button>
                    <button
                      type="button"
                      className={`flex items-center justify-center p-4 border rounded-lg transition-colors ${
                        userRole === 'recipient'
                          ? 'border-red-500 bg-red-50 text-red-700'
                          : 'border-gray-300 hover:bg-gray-50'
                      }`}
                      onClick={() => setUserRole('recipient')}
                    >
                      <User size={20} className="mr-2" />
                      Need Blood
                    </button>
                  </div>
                </div>

                {/* Basic Info */}
                <div className="mb-4">
                  <label htmlFor="name" className="form-label">
                    Full Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    className={`form-input ${errors.name ? 'border-red-500' : ''}`}
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Enter your full name"
                  />
                  {errors.name && <p className="error-message">{errors.name}</p>}
                </div>

                <div className="mb-4">
                  <label htmlFor="email" className="form-label">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    className={`form-input ${errors.email ? 'border-red-500' : ''}`}
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="Enter your email"
                  />
                  {errors.email && <p className="error-message">{errors.email}</p>}
                </div>

                <div className="mb-4">
                  <label htmlFor="password" className="form-label">
                    Password
                  </label>
                  <input
                    type="password"
                    id="password"
                    name="password"
                    className={`form-input ${errors.password ? 'border-red-500' : ''}`}
                    value={formData.password}
                    onChange={handleInputChange}
                    placeholder="Create a password"
                  />
                  {errors.password && <p className="error-message">{errors.password}</p>}
                </div>

                <div className="mb-4">
                  <label htmlFor="phone" className="form-label">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    className={`form-input ${errors.phone ? 'border-red-500' : ''}`}
                    value={formData.phone}
                    onChange={handleInputChange}
                    placeholder="10-digit mobile number"
                  />
                  {errors.phone && <p className="error-message">{errors.phone}</p>}
                </div>

                {/* Blood Type (only for donors) */}
                {userRole === 'donor' && (
                  <div className="mb-4">
                    <label htmlFor="bloodType" className="form-label">
                      Blood Type
                    </label>
                    <select
                      id="bloodType"
                      name="bloodType"
                      className={`form-select ${errors.bloodType ? 'border-red-500' : ''}`}
                      value={formData.bloodType}
                      onChange={handleInputChange}
                    >
                      <option value="">Select Blood Type</option>
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                      <option value="O+">O+</option>
                      <option value="O-">O-</option>
                    </select>
                    {errors.bloodType && <p className="error-message">{errors.bloodType}</p>}
                  </div>
                )}

                {/* Location */}
                <div className="mb-4">
                  <label htmlFor="state" className="form-label">
                    State
                  </label>
                  <select
                    id="state"
                    name="state"
                    className={`form-select ${errors.state ? 'border-red-500' : ''}`}
                    value={formData.state}
                    onChange={handleInputChange}
                  >
                    <option value="">Select State</option>
                    {states.map((state) => (
                      <option key={state} value={state}>
                        {state}
                      </option>
                    ))}
                  </select>
                  {errors.state && <p className="error-message">{errors.state}</p>}
                </div>

                <div className="mb-4">
                  <label htmlFor="city" className="form-label">
                    City
                  </label>
                  <input
                    type="text"
                    id="city"
                    name="city"
                    className={`form-input ${errors.city ? 'border-red-500' : ''}`}
                    value={formData.city}
                    onChange={handleInputChange}
                    placeholder="Enter your city"
                  />
                  {errors.city && <p className="error-message">{errors.city}</p>}
                </div>

                <div className="mb-4">
                  <label htmlFor="pincode" className="form-label">
                    Pincode
                  </label>
                  <input
                    type="text"
                    id="pincode"
                    name="pincode"
                    className={`form-input ${errors.pincode ? 'border-red-500' : ''}`}
                    value={formData.pincode}
                    onChange={handleInputChange}
                    placeholder="6-digit pincode"
                  />
                  {errors.pincode && <p className="error-message">{errors.pincode}</p>}
                </div>

                {/* Terms and Conditions */}
                <div className="mb-6">
                  <label className="flex items-start">
                    <input
                      type="checkbox"
                      name="agreeToTerms"
                      className="mt-1 mr-2"
                      checked={formData.agreeToTerms}
                      onChange={handleInputChange}
                    />
                    <span className="text-sm text-gray-600">
                      I agree to the{' '}
                      <a href="#" className="text-red-600 hover:underline">
                        Terms of Service
                      </a>{' '}
                      and{' '}
                      <a href="#" className="text-red-600 hover:underline">
                        Privacy Policy
                      </a>
                    </span>
                  </label>
                  {errors.agreeToTerms && (
                    <p className="error-message">{errors.agreeToTerms}</p>
                  )}
                </div>

                <button type="submit" className="btn-primary w-full">
                  Create Account
                </button>
              </form>
            ) : (
              // Login Form
              <form onSubmit={handleLoginSubmit}>
                <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">
                  Welcome Back
                </h2>

                {/* User Type Selection */}
                <div className="mb-6">
                  <label className="block text-gray-700 mb-2">Login as:</label>
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      type="button"
                      className={`flex items-center justify-center p-4 border rounded-lg transition-colors ${
                        userRole === 'donor'
                          ? 'border-red-500 bg-red-50 text-red-700'
                          : 'border-gray-300 hover:bg-gray-50'
                      }`}
                      onClick={() => setUserRole('donor')}
                    >
                      <DropletHalf size={20} className="mr-2" />
                      Donor
                    </button>
                    <button
                      type="button"
                      className={`flex items-center justify-center p-4 border rounded-lg transition-colors ${
                        userRole === 'recipient'
                          ? 'border-red-500 bg-red-50 text-red-700'
                          : 'border-gray-300 hover:bg-gray-50'
                      }`}
                      onClick={() => setUserRole('recipient')}
                    >
                      <User size={20} className="mr-2" />
                      Recipient
                    </button>
                  </div>
                </div>

                <div className="mb-4">
                  <label htmlFor="login-email" className="form-label">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="login-email"
                    name="email"
                    className="form-input"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="Enter your email"
                  />
                </div>

                <div className="mb-6">
                  <label htmlFor="login-password" className="form-label">
                    Password
                  </label>
                  <input
                    type="password"
                    id="login-password"
                    name="password"
                    className="form-input"
                    value={formData.password}
                    onChange={handleInputChange}
                    placeholder="Enter your password"
                  />
                  <div className="flex justify-end mt-1">
                    <a href="#" className="text-sm text-red-600 hover:underline">
                      Forgot password?
                    </a>
                  </div>
                </div>

                <button type="submit" className="btn-primary w-full">
                  Login
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;