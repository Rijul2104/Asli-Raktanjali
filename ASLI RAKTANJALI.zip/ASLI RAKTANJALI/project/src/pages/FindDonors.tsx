import React, { useState } from 'react';
import { Search, MapPin, Filter, Droplet as DropletHalf, Phone, Mail, ChevronDown, ChevronUp } from 'lucide-react';
import { states } from '../data/states';

interface Donor {
  id: number;
  name: string;
  bloodType: string;
  city: string;
  state: string;
  distance: string;
  lastDonation: string;
  availableFrom: string;
}

const FindDonors: React.FC = () => {
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [filters, setFilters] = useState({
    bloodType: '',
    state: '',
    city: '',
    pincode: '',
    distance: '25',
    availability: 'any',
  });

  // Mock donor data
  const donors: Donor[] = [
    {
      id: 1,
      name: 'Rajesh Sharma',
      bloodType: 'A+',
      city: 'Pune',
      state: 'Maharashtra',
      distance: '3.2 km',
      lastDonation: '3 months ago',
      availableFrom: '2025-03-15',
    },
    {
      id: 2,
      name: 'Priya Patel',
      bloodType: 'B+',
      city: 'Pune',
      state: 'Maharashtra',
      distance: '5.7 km',
      lastDonation: '5 months ago',
      availableFrom: 'Immediately',
    },
    {
      id: 3,
      name: 'Amit Kumar',
      bloodType: 'O+',
      city: 'Pune',
      state: 'Maharashtra',
      distance: '7.3 km',
      lastDonation: '7 months ago',
      availableFrom: 'Immediately',
    },
    {
      id: 4,
      name: 'Deepika Singh',
      bloodType: 'AB-',
      city: 'Pune',
      state: 'Maharashtra',
      distance: '10.1 km',
      lastDonation: '4 months ago',
      availableFrom: '2025-02-20',
    },
    {
      id: 5,
      name: 'Rahul Verma',
      bloodType: 'O-',
      city: 'Pune',
      state: 'Maharashtra',
      distance: '12.4 km',
      lastDonation: '8 months ago',
      availableFrom: 'Immediately',
    },
  ];

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters({
      ...filters,
      [name]: value,
    });
  };

  const toggleFilters = () => {
    setFiltersOpen(!filtersOpen);
  };

  const bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold font-serif text-gray-800 mb-4">
            Find Blood Donors
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Search for blood donors by blood type, location, and availability.
            Connect directly with donors to arrange donations.
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="bg-white rounded-lg shadow-md mb-8 overflow-hidden">
          <div className="p-6">
            <div className="flex flex-col md:flex-row md:items-end gap-4">
              <div className="flex-1">
                <label htmlFor="bloodType" className="form-label">
                  Blood Type
                </label>
                <select
                  id="bloodType"
                  name="bloodType"
                  className="form-select"
                  value={filters.bloodType}
                  onChange={handleFilterChange}
                >
                  <option value="">Any Blood Type</option>
                  {bloodTypes.map(type => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex-1">
                <label htmlFor="state" className="form-label">
                  State
                </label>
                <select
                  id="state"
                  name="state"
                  className="form-select"
                  value={filters.state}
                  onChange={handleFilterChange}
                >
                  <option value="">Select State</option>
                  {states.map(state => (
                    <option key={state} value={state}>
                      {state}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex-1">
                <label htmlFor="city" className="form-label">
                  City
                </label>
                <input
                  type="text"
                  id="city"
                  name="city"
                  className="form-input"
                  placeholder="Enter city"
                  value={filters.city}
                  onChange={handleFilterChange}
                />
              </div>

              <div className="md:ml-2 flex-shrink-0">
                <button className="btn-primary flex items-center">
                  <Search size={18} className="mr-2" />
                  Search Donors
                </button>
              </div>
            </div>

            <div className="mt-4">
              <button
                onClick={toggleFilters}
                className="text-gray-700 flex items-center text-sm font-medium"
              >
                <Filter size={16} className="mr-1" />
                Advanced Filters
                {filtersOpen ? (
                  <ChevronUp size={16} className="ml-1" />
                ) : (
                  <ChevronDown size={16} className="ml-1" />
                )}
              </button>
            </div>

            {filtersOpen && (
              <div className="mt-4 pt-4 border-t border-gray-200 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label htmlFor="pincode" className="form-label">
                    Pincode
                  </label>
                  <input
                    type="text"
                    id="pincode"
                    name="pincode"
                    className="form-input"
                    placeholder="6-digit pincode"
                    value={filters.pincode}
                    onChange={handleFilterChange}
                  />
                </div>

                <div>
                  <label htmlFor="distance" className="form-label">
                    Distance (km)
                  </label>
                  <select
                    id="distance"
                    name="distance"
                    className="form-select"
                    value={filters.distance}
                    onChange={handleFilterChange}
                  >
                    <option value="5">Within 5 km</option>
                    <option value="10">Within 10 km</option>
                    <option value="25">Within 25 km</option>
                    <option value="50">Within 50 km</option>
                    <option value="100">Within 100 km</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="availability" className="form-label">
                    Availability
                  </label>
                  <select
                    id="availability"
                    name="availability"
                    className="form-select"
                    value={filters.availability}
                    onChange={handleFilterChange}
                  >
                    <option value="any">Any availability</option>
                    <option value="immediate">Available immediately</option>
                    <option value="this-week">Available this week</option>
                    <option value="this-month">Available this month</option>
                  </select>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Results */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-800">
              {donors.length} Donors Found
            </h2>
            <div className="flex items-center">
              <span className="text-gray-600 mr-2">Sort by:</span>
              <select className="form-select-sm w-auto">
                <option value="distance">Distance</option>
                <option value="available">Availability</option>
                <option value="last-donation">Last Donation Date</option>
              </select>
            </div>
          </div>

          {/* Donor Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {donors.map((donor) => (
              <div key={donor.id} className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-100">
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center">
                      <div className="bg-red-100 text-red-600 rounded-full w-12 h-12 flex items-center justify-center font-bold text-lg mr-4">
                        {donor.bloodType}
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">{donor.name}</h3>
                        <div className="flex items-center text-gray-600 text-sm">
                          <MapPin size={14} className="mr-1" />
                          <span>{donor.city}, {donor.state}</span>
                        </div>
                      </div>
                    </div>
                    <span className="text-sm bg-gray-100 text-gray-700 px-2 py-1 rounded-full">
                      {donor.distance}
                    </span>
                  </div>

                  <div className="space-y-2 mb-6">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Last Donation:</span>
                      <span className="font-medium">{donor.lastDonation}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Available:</span>
                      <span className={`font-medium ${donor.availableFrom === 'Immediately' ? 'text-green-600' : ''}`}>
                        {donor.availableFrom}
                      </span>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t border-gray-100 flex justify-between">
                    <button className="btn-outline flex items-center">
                      <Mail size={16} className="mr-2" />
                      Message
                    </button>
                    <button className="btn-primary flex items-center">
                      <Phone size={16} className="mr-2" />
                      Contact
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Blood Type Information */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-12">
          <h2 className="text-xl font-semibold mb-6">Blood Type Compatibility Chart</h2>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-4 py-3 text-left font-medium text-gray-600">Blood Type</th>
                  <th className="px-4 py-3 text-left font-medium text-gray-600">Can Donate To</th>
                  <th className="px-4 py-3 text-left font-medium text-gray-600">Can Receive From</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">A+</span>
                  </td>
                  <td className="px-4 py-3">A+, AB+</td>
                  <td className="px-4 py-3">A+, A-, O+, O-</td>
                </tr>
                <tr>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">A-</span>
                  </td>
                  <td className="px-4 py-3">A+, A-, AB+, AB-</td>
                  <td className="px-4 py-3">A-, O-</td>
                </tr>
                <tr>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">B+</span>
                  </td>
                  <td className="px-4 py-3">B+, AB+</td>
                  <td className="px-4 py-3">B+, B-, O+, O-</td>
                </tr>
                <tr>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">B-</span>
                  </td>
                  <td className="px-4 py-3">B+, B-, AB+, AB-</td>
                  <td className="px-4 py-3">B-, O-</td>
                </tr>
                <tr>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">AB+</span>
                  </td>
                  <td className="px-4 py-3">AB+ only</td>
                  <td className="px-4 py-3">Everyone (Universal recipient)</td>
                </tr>
                <tr>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">AB-</span>
                  </td>
                  <td className="px-4 py-3">AB+, AB-</td>
                  <td className="px-4 py-3">A-, B-, AB-, O-</td>
                </tr>
                <tr>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">O+</span>
                  </td>
                  <td className="px-4 py-3">O+, A+, B+, AB+</td>
                  <td className="px-4 py-3">O+, O-</td>
                </tr>
                <tr>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">O-</span>
                  </td>
                  <td className="px-4 py-3">Everyone (Universal donor)</td>
                  <td className="px-4 py-3">O- only</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* CTA */}
        <div className="bg-red-600 text-white rounded-lg shadow-lg p-8 text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">
              Not finding what you need?
            </h2>
            <p className="text-lg mb-6">
              Create a blood request and let donors in your area know about your needs.
            </p>
            <a
              href="/request-blood"
              className="inline-block px-6 py-3 bg-white text-red-600 font-medium rounded-md hover:bg-gray-100 transition-colors"
            >
              Create Blood Request
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FindDonors;