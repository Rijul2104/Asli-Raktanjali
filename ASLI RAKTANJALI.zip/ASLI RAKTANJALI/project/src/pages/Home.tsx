import React from 'react';
import { Link } from 'react-router-dom';
import { Droplet as DropletHalf, Search, Heart, Clock, Users } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-red-700 to-red-500 text-white py-20">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/6823562/pexels-photo-6823562.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center opacity-20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold font-serif mb-6 leading-tight">
              Give the Gift of Life: <span className="text-yellow-300">Donate Blood Today</span>
            </h1>
            <p className="text-lg md:text-xl mb-8">
              Raktanjali connects blood donors with those in need across India. Your donation can save up to three lives.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/register" className="btn-primary">
                Become a Donor
              </Link>
              <Link to="/request-blood" className="btn-secondary">
                Request Blood
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="stat-card">
              <div className="text-red-600 mb-4">
                <DropletHalf size={40} />
              </div>
              <h3 className="text-3xl font-bold mb-2">10,000+</h3>
              <p className="text-gray-600">Donations Made</p>
            </div>
            <div className="stat-card">
              <div className="text-red-600 mb-4">
                <Users size={40} />
              </div>
              <h3 className="text-3xl font-bold mb-2">5,000+</h3>
              <p className="text-gray-600">Registered Donors</p>
            </div>
            <div className="stat-card">
              <div className="text-red-600 mb-4">
                <Heart size={40} />
              </div>
              <h3 className="text-3xl font-bold mb-2">15,000+</h3>
              <p className="text-gray-600">Lives Saved</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold font-serif text-gray-800 mb-4">How It Works</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Raktanjali makes it easy to donate blood or find donors when you need them.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="process-card">
              <div className="process-icon">
                <Users size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Register</h3>
              <p className="text-gray-600">
                Sign up as a donor or recipient with your basic details and location information.
              </p>
            </div>
            
            <div className="process-card">
              <div className="process-icon">
                <Search size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Find Matches</h3>
              <p className="text-gray-600">
                Search for blood donors or recipients by blood type, location, and availability.
              </p>
            </div>
            
            <div className="process-card">
              <div className="process-icon">
                <Heart size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Save Lives</h3>
              <p className="text-gray-600">
                Connect directly with donors or recipients and arrange the donation.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Requests */}
      <section className="py-16 bg-red-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold font-serif text-gray-800 mb-4">Emergency Requests</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              These blood requests need immediate attention. If you can help, please respond.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="emergency-card">
              <div className="flex justify-between items-start mb-4">
                <div className="blood-type">A+</div>
                <div className="emergency-badge">
                  <Clock size={14} className="mr-1" />
                  Urgent
                </div>
              </div>
              <h3 className="text-lg font-semibold mb-2">Needed at Apollo Hospital</h3>
              <p className="text-gray-600 mb-4">Pune, Maharashtra - 411001</p>
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-500">Posted 2 hours ago</p>
                <button className="emergency-btn">Respond</button>
              </div>
            </div>
            
            <div className="emergency-card">
              <div className="flex justify-between items-start mb-4">
                <div className="blood-type">O-</div>
                <div className="emergency-badge">
                  <Clock size={14} className="mr-1" />
                  Urgent
                </div>
              </div>
              <h3 className="text-lg font-semibold mb-2">Needed at AIIMS</h3>
              <p className="text-gray-600 mb-4">Delhi - 110029</p>
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-500">Posted 5 hours ago</p>
                <button className="emergency-btn">Respond</button>
              </div>
            </div>
            
            <div className="emergency-card">
              <div className="flex justify-between items-start mb-4">
                <div className="blood-type">B+</div>
                <div className="emergency-badge">
                  <Clock size={14} className="mr-1" />
                  Urgent
                </div>
              </div>
              <h3 className="text-lg font-semibold mb-2">Needed at City Hospital</h3>
              <p className="text-gray-600 mb-4">Mumbai, Maharashtra - 400001</p>
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-500">Posted 1 day ago</p>
                <button className="emergency-btn">Respond</button>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-8">
            <Link to="/find-donors" className="text-red-600 font-medium hover:text-red-700 transition-colors flex items-center justify-center">
              View All Requests
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-red-700 to-red-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold font-serif mb-6">Ready to Make a Difference?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Your blood donation can save up to three lives. Join our community of donors today and be a hero to someone in need.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register" className="btn-secondary-light">
              Join as Donor
            </Link>
            <Link to="/find-donors" className="btn-outline-light">
              Find Blood
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;