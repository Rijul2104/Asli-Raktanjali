import React, { useState } from 'react';
import { useUser } from '../context/UserContext';
import { Calendar, Droplet as DropletHalf, Bell, MapPin, Settings, LogOut, Search, Clock, UserPlus, CheckSquare } from 'lucide-react';

const RecipientDashboard: React.FC = () => {
  const { userData, logout } = useUser();
  const [activeTab, setActiveTab] = useState('overview');

  // Simulated request data
  const requests = [
    { 
      id: 1, 
      date: '2025-02-12', 
      bloodType: 'A+', 
      hospital: 'Ruby Hall Clinic, Pune', 
      units: 2,
      status: 'Active',
      responses: 3 
    },
    { 
      id: 2, 
      date: '2024-12-05', 
      bloodType: 'A+', 
      hospital: 'Sahyadri Hospital, Pune', 
      units: 1,
      status: 'Completed',
      responses: 2 
    },
  ];

  // Simulated nearby donors
  const nearbyDonors = [
    { id: 1, name: 'Rahul S.', bloodType: 'A+', location: 'Pune', distance: '3 km', lastDonation: '3 months ago' },
    { id: 2, name: 'Priya M.', bloodType: 'O-', location: 'Pune', distance: '5 km', lastDonation: '4 months ago' },
    { id: 3, name: 'Aditya K.', bloodType: 'B+', location: 'Pune', distance: '7 km', lastDonation: '6 months ago' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              {/* Profile header */}
              <div className="bg-red-600 p-6 text-white">
                <div className="flex items-center space-x-4">
                  <div className="bg-white text-red-600 rounded-full w-12 h-12 flex items-center justify-center font-bold text-lg">
                    {userData?.name?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <h2 className="font-semibold text-lg">{userData?.name || 'User'}</h2>
                    <p className="text-red-100 text-sm">Recipient</p>
                  </div>
                </div>
              </div>

              {/* Location info */}
              <div className="p-6 border-b">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-gray-500 text-sm">Location</p>
                    <p className="font-medium">{userData?.city || 'Pune'}, {userData?.state || 'Maharashtra'}</p>
                    <p className="text-sm text-gray-500">{userData?.pincode || '411001'}</p>
                  </div>
                  <div className="bg-red-50 p-3 rounded-full">
                    <MapPin className="text-red-600" size={24} />
                  </div>
                </div>
              </div>

              {/* Navigation */}
              <nav className="p-4">
                <ul className="space-y-2">
                  <li>
                    <button 
                      onClick={() => setActiveTab('overview')} 
                      className={`nav-item ${activeTab === 'overview' ? 'bg-red-50 text-red-600' : ''}`}
                    >
                      <Search size={20} />
                      <span>Overview</span>
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => setActiveTab('requests')} 
                      className={`nav-item ${activeTab === 'requests' ? 'bg-red-50 text-red-600' : ''}`}
                    >
                      <DropletHalf size={20} />
                      <span>My Requests</span>
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => setActiveTab('donors')} 
                      className={`nav-item ${activeTab === 'donors' ? 'bg-red-50 text-red-600' : ''}`}
                    >
                      <UserPlus size={20} />
                      <span>Find Donors</span>
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => setActiveTab('create')} 
                      className={`nav-item ${activeTab === 'create' ? 'bg-red-50 text-red-600' : ''}`}
                    >
                      <Bell size={20} />
                      <span>Create Request</span>
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => setActiveTab('settings')} 
                      className={`nav-item ${activeTab === 'settings' ? 'bg-red-50 text-red-600' : ''}`}
                    >
                      <Settings size={20} />
                      <span>Settings</span>
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={logout} 
                      className="nav-item text-gray-700 hover:bg-gray-100"
                    >
                      <LogOut size={20} />
                      <span>Logout</span>
                    </button>
                  </li>
                </ul>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Stats Row */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-gray-500 font-medium">Active Requests</h3>
                      <Bell className="text-red-500" size={20} />
                    </div>
                    <p className="text-3xl font-bold">
                      {requests.filter(r => r.status === 'Active').length}
                    </p>
                    <p className="text-sm text-gray-500 mt-2">Current requests</p>
                  </div>
                  
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-gray-500 font-medium">Total Responses</h3>
                      <UserPlus className="text-red-500" size={20} />
                    </div>
                    <p className="text-3xl font-bold">
                      {requests.reduce((sum, req) => sum + req.responses, 0)}
                    </p>
                    <p className="text-sm text-gray-500 mt-2">From potential donors</p>
                  </div>
                  
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-gray-500 font-medium">Fulfilled Requests</h3>
                      <CheckSquare className="text-red-500" size={20} />
                    </div>
                    <p className="text-3xl font-bold">
                      {requests.filter(r => r.status === 'Completed').length}
                    </p>
                    <p className="text-sm text-gray-500 mt-2">Successfully completed</p>
                  </div>
                </div>

                {/* Active Requests */}
                <div className="bg-white rounded-lg shadow-md p-6">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-semibold">Active Blood Requests</h2>
                    <button 
                      onClick={() => setActiveTab('create')}
                      className="text-red-600 text-sm font-medium hover:underline flex items-center"
                    >
                      <Bell size={16} className="mr-1" />
                      New Request
                    </button>
                  </div>
                  
                  {requests.filter(r => r.status === 'Active').length > 0 ? (
                    <div className="space-y-4">
                      {requests
                        .filter(r => r.status === 'Active')
                        .map(request => (
                          <div key={request.id} className="border rounded-lg p-4">
                            <div className="flex justify-between">
                              <div className="flex items-center space-x-4">
                                <div className="bg-red-100 text-red-600 font-bold rounded-full w-12 h-12 flex items-center justify-center">
                                  {request.bloodType}
                                </div>
                                <div>
                                  <h3 className="font-medium">{request.hospital}</h3>
                                  <p className="text-gray-500 text-sm">{request.date} • {request.units} units needed</p>
                                </div>
                              </div>
                              <div className="bg-green-100 text-green-700 px-3 py-1 h-min rounded-full text-xs font-medium">
                                {request.responses} responses
                              </div>
                            </div>
                            
                            <div className="mt-4 flex justify-end">
                              <button className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors">
                                View Details
                              </button>
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Bell className="mx-auto text-gray-300" size={48} />
                      <p className="mt-4 text-gray-500">No active blood requests</p>
                      <button 
                        onClick={() => setActiveTab('create')}
                        className="mt-4 btn-primary"
                      >
                        Create New Request
                      </button>
                    </div>
                  )}
                </div>

                {/* Nearby Donors */}
                <div className="bg-white rounded-lg shadow-md p-6">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-semibold">Nearby Donors</h2>
                    <button 
                      onClick={() => setActiveTab('donors')}
                      className="text-red-600 text-sm font-medium hover:underline"
                    >
                      View All
                    </button>
                  </div>
                  
                  <div className="space-y-4">
                    {nearbyDonors.slice(0, 2).map(donor => (
                      <div key={donor.id} className="border rounded-lg p-4 flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="bg-red-100 text-red-600 font-bold rounded-full w-12 h-12 flex items-center justify-center mr-4">
                            {donor.bloodType}
                          </div>
                          <div>
                            <h3 className="font-medium">{donor.name}</h3>
                            <div className="flex items-center text-gray-500 text-sm">
                              <MapPin size={14} className="mr-1" />
                              <span>{donor.location} • {donor.distance}</span>
                            </div>
                          </div>
                        </div>
                        <button className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors">
                          Contact
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'requests' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-6">My Blood Requests</h2>
                
                <div className="mb-6">
                  <div className="flex space-x-4">
                    <button className="px-4 py-2 bg-red-600 text-white rounded-md">
                      All Requests
                    </button>
                    <button className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md">
                      Active
                    </button>
                    <button className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md">
                      Completed
                    </button>
                  </div>
                </div>
                
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Date</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Blood Type</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Hospital</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Units</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Status</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Responses</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {requests.map(request => (
                        <tr key={request.id}>
                          <td className="px-4 py-4 text-sm text-gray-900">{request.date}</td>
                          <td className="px-4 py-4 text-sm text-gray-900">
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                              {request.bloodType}
                            </span>
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-900">{request.hospital}</td>
                          <td className="px-4 py-4 text-sm text-gray-900">{request.units}</td>
                          <td className="px-4 py-4 text-sm text-gray-900">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              request.status === 'Active' 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-gray-100 text-gray-800'
                            }`}>
                              {request.status}
                            </span>
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-900">{request.responses}</td>
                          <td className="px-4 py-4 text-sm text-gray-900">
                            <button className="text-red-600 hover:text-red-800 font-medium">
                              View
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                {requests.length === 0 && (
                  <div className="text-center py-12">
                    <Bell className="mx-auto text-gray-300" size={48} />
                    <p className="mt-4 text-gray-500">You haven't created any blood requests yet.</p>
                    <button 
                      onClick={() => setActiveTab('create')}
                      className="mt-4 btn-primary"
                    >
                      Create New Request
                    </button>
                  </div>
                )}
              </div>
            )}
            
            {activeTab === 'donors' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-6">Find Blood Donors</h2>
                
                <div className="mb-6 bg-gray-50 p-4 rounded-lg">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                      <label htmlFor="donor-blood-type" className="form-label">Blood Type</label>
                      <select id="donor-blood-type" className="form-select">
                        <option value="">Any Blood Type</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                      </select>
                    </div>
                    <div>
                      <label htmlFor="donor-state" className="form-label">State</label>
                      <select id="donor-state" className="form-select">
                        <option value="">Any State</option>
                        <option value="Maharashtra" selected>Maharashtra</option>
                        <option value="Delhi">Delhi</option>
                        <option value="Karnataka">Karnataka</option>
                        <option value="Tamil Nadu">Tamil Nadu</option>
                      </select>
                    </div>
                    <div>
                      <label htmlFor="donor-city" className="form-label">City</label>
                      <input type="text" id="donor-city" className="form-input" placeholder="Enter city" defaultValue="Pune" />
                    </div>
                    <div>
                      <label htmlFor="donor-distance" className="form-label">Distance (km)</label>
                      <select id="donor-distance" className="form-select">
                        <option value="5">Within 5 km</option>
                        <option value="10" selected>Within 10 km</option>
                        <option value="25">Within 25 km</option>
                        <option value="50">Within 50 km</option>
                      </select>
                    </div>
                  </div>
                  <div className="mt-4 flex justify-end">
                    <button className="btn-primary">
                      <Search size={16} className="mr-2" />
                      Search Donors
                    </button>
                  </div>
                </div>
                
                <div className="space-y-4">
                  {nearbyDonors.map(donor => (
                    <div key={donor.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center space-x-4">
                          <div className="bg-red-100 text-red-600 font-bold rounded-full w-12 h-12 flex items-center justify-center">
                            {donor.bloodType}
                          </div>
                          <div>
                            <h3 className="font-medium">{donor.name}</h3>
                            <div className="flex items-center text-gray-500 text-sm">
                              <MapPin size={14} className="mr-1" />
                              <span>{donor.location} • {donor.distance}</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-sm text-gray-500">
                          Last donation: {donor.lastDonation}
                        </div>
                      </div>
                      
                      <div className="mt-4 flex justify-end space-x-3">
                        <button className="px-4 py-2 border border-red-600 text-red-600 rounded-md hover:bg-red-50 transition-colors">
                          View Profile
                        </button>
                        <button className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors">
                          Contact
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {activeTab === 'create' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-6">Create Blood Request</h2>
                
                <form className="space-y-6">
                  <div className="bg-red-50 p-4 rounded-lg border border-red-100 mb-6">
                    <div className="flex items-start">
                      <div className="mt-0.5 mr-2 text-red-500">
                        <Bell size={20} />
                      </div>
                      <div>
                        <h3 className="font-medium text-red-800">Important Information</h3>
                        <p className="text-sm text-red-700">
                          Only create blood requests for genuine medical needs. Provide accurate information and the required hospital details.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Patient Details */}
                    <div>
                      <h3 className="text-lg font-medium mb-4">Patient Details</h3>
                      
                      <div className="space-y-4">
                        <div>
                          <label htmlFor="patient-name" className="form-label">Patient Name</label>
                          <input type="text" id="patient-name" className="form-input" placeholder="Enter patient name" />
                        </div>
                        
                        <div>
                          <label htmlFor="patient-age" className="form-label">Patient Age</label>
                          <input type="number" id="patient-age" className="form-input" placeholder="Enter age" />
                        </div>
                        
                        <div>
                          <label htmlFor="patient-gender" className="form-label">Patient Gender</label>
                          <select id="patient-gender" className="form-select">
                            <option value="">Select gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="other">Other</option>
                          </select>
                        </div>
                        
                        <div>
                          <label htmlFor="medical-condition" className="form-label">Medical Condition</label>
                          <textarea 
                            id="medical-condition" 
                            className="form-textarea" 
                            rows={3}
                            placeholder="Briefly describe the medical condition requiring blood..."
                          ></textarea>
                        </div>
                      </div>
                    </div>
                    
                    {/* Request Details */}
                    <div>
                      <h3 className="text-lg font-medium mb-4">Request Details</h3>
                      
                      <div className="space-y-4">
                        <div>
                          <label htmlFor="blood-type" className="form-label">Blood Type Needed</label>
                          <select id="blood-type" className="form-select">
                            <option value="">Select blood type</option>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                          </select>
                        </div>
                        
                        <div>
                          <label htmlFor="units-needed" className="form-label">Units Needed</label>
                          <select id="units-needed" className="form-select">
                            <option value="1">1 unit</option>
                            <option value="2">2 units</option>
                            <option value="3">3 units</option>
                            <option value="4">4 units</option>
                            <option value="5+">5+ units</option>
                          </select>
                        </div>
                        
                        <div>
                          <label htmlFor="urgency" className="form-label">Urgency Level</label>
                          <select id="urgency" className="form-select">
                            <option value="low">Low - Within a week</option>
                            <option value="medium">Medium - Within 2-3 days</option>
                            <option value="high">High - Within 24 hours</option>
                            <option value="critical">Critical - Immediate</option>
                          </select>
                        </div>
                        
                        <div>
                          <label htmlFor="required-by" className="form-label">Required By Date</label>
                          <input type="date" id="required-by" className="form-input" />
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Hospital Information */}
                  <div className="mt-6">
                    <h3 className="text-lg font-medium mb-4">Hospital Information</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="hospital-name" className="form-label">Hospital Name</label>
                        <input type="text" id="hospital-name" className="form-input" placeholder="Enter hospital name" />
                      </div>
                      
                      <div>
                        <label htmlFor="hospital-address" className="form-label">Hospital Address</label>
                        <input type="text" id="hospital-address" className="form-input" placeholder="Enter hospital address" />
                      </div>
                      
                      <div>
                        <label htmlFor="hospital-city" className="form-label">City</label>
                        <input 
                          type="text" 
                          id="hospital-city" 
                          className="form-input" 
                          defaultValue={userData?.city || 'Pune'} 
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="hospital-pincode" className="form-label">Pincode</label>
                        <input 
                          type="text" 
                          id="hospital-pincode" 
                          className="form-input" 
                          defaultValue={userData?.pincode || '411001'} 
                        />
                      </div>
                    </div>
                  </div>
                  
                  {/* Contact Information */}
                  <div className="mt-6">
                    <h3 className="text-lg font-medium mb-4">Contact Information</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="contact-name" className="form-label">Contact Person</label>
                        <input 
                          type="text" 
                          id="contact-name" 
                          className="form-input" 
                          defaultValue={userData?.name} 
                          placeholder="Enter contact person name" 
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="contact-phone" className="form-label">Contact Phone</label>
                        <input 
                          type="tel" 
                          id="contact-phone" 
                          className="form-input" 
                          defaultValue={userData?.phone} 
                          placeholder="10-digit mobile number" 
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="alternate-phone" className="form-label">Alternate Phone (Optional)</label>
                        <input type="tel" id="alternate-phone" className="form-input" placeholder="10-digit mobile number" />
                      </div>
                      
                      <div>
                        <label htmlFor="contact-email" className="form-label">Email</label>
                        <input 
                          type="email" 
                          id="contact-email" 
                          className="form-input" 
                          defaultValue={userData?.email} 
                          placeholder="Enter email address" 
                        />
                      </div>
                    </div>
                  </div>
                  
                  {/* Additional Notes */}
                  <div className="mt-6">
                    <label htmlFor="additional-notes" className="form-label">Additional Notes (Optional)</label>
                    <textarea 
                      id="additional-notes" 
                      className="form-textarea" 
                      rows={3}
                      placeholder="Any additional information that donors should know..."
                    ></textarea>
                  </div>
                  
                  {/* Terms Checkbox */}
                  <div className="mt-6">
                    <label className="flex items-start">
                      <input
                        type="checkbox"
                        className="mt-1 mr-2"
                      />
                      <span className="text-sm text-gray-600">
                        I confirm that this request is for a genuine medical need and all information provided is accurate. 
                        I agree to Raktanjali's <a href="#" className="text-red-600 hover:underline">Terms of Service</a> and <a href="#" className="text-red-600 hover:underline">Privacy Policy</a>.
                      </span>
                    </label>
                  </div>
                  
                  <button type="submit" className="btn-primary">
                    Create Blood Request
                  </button>
                </form>
              </div>
            )}
            
            {activeTab === 'settings' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-6">Settings</h2>
                
                {/* Similar to DonorDashboard settings, but with recipient-specific fields */}
                <div className="space-y-6">
                  {/* Profile Settings */}
                  <div>
                    <h3 className="text-lg font-medium mb-4">Profile Information</h3>
                    <form className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="settings-name" className="form-label">Full Name</label>
                          <input 
                            type="text" 
                            id="settings-name" 
                            className="form-input" 
                            defaultValue={userData?.name}
                          />
                        </div>
                        <div>
                          <label htmlFor="settings-email" className="form-label">Email Address</label>
                          <input 
                            type="email" 
                            id="settings-email" 
                            className="form-input" 
                            defaultValue={userData?.email}
                          />
                        </div>
                        <div>
                          <label htmlFor="settings-phone" className="form-label">Phone Number</label>
                          <input 
                            type="tel" 
                            id="settings-phone" 
                            className="form-input" 
                            defaultValue={userData?.phone}
                          />
                        </div>
                      </div>
                      
                      <button type="submit" className="btn-primary">
                        Update Profile
                      </button>
                    </form>
                  </div>
                  
                  {/* Additional settings sections similar to DonorDashboard */}
                  {/* (Location Settings, Password Settings, Notification Settings) */}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecipientDashboard;