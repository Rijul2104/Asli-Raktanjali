import React, { useState } from 'react';
import { useUser } from '../context/UserContext';
import { Calendar, Droplet as DropletHalf, Bell, MapPin, Settings, LogOut, Award, Clock } from 'lucide-react';

const DonorDashboard: React.FC = () => {
  const { userData, logout } = useUser();
  const [activeTab, setActiveTab] = useState('overview');

  // Simulated donation data
  const donations = [
    { id: 1, date: '2025-01-15', location: 'Blood Bank, Civil Hospital, Pune', bloodType: 'A+', units: 1 },
    { id: 2, date: '2024-10-22', location: 'Red Cross Blood Drive, Delhi', bloodType: 'A+', units: 1 },
    { id: 3, date: '2024-07-30', location: 'AIIMS Blood Bank, Delhi', bloodType: 'A+', units: 1 },
  ];

  // Simulated nearby requests
  const nearbyRequests = [
    { id: 1, bloodType: 'A+', hospital: 'City Hospital', city: 'Pune', urgency: 'High', postedOn: '1 hour ago' },
    { id: 2, bloodType: 'O-', hospital: 'Apollo Hospital', city: 'Pune', urgency: 'Medium', postedOn: '3 hours ago' },
    { id: 3, bloodType: 'B+', hospital: 'Ruby Hall Clinic', city: 'Pune', urgency: 'Low', postedOn: '1 day ago' },
  ];

  // Calculate next eligible donation date (assuming 3 months between donations)
  const lastDonationDate = new Date(donations[0]?.date || '2025-01-15');
  const nextEligibleDate = new Date(lastDonationDate);
  nextEligibleDate.setMonth(nextEligibleDate.getMonth() + 3);
  const nextEligibleFormatted = nextEligibleDate.toISOString().split('T')[0];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              {/* Profile header */}
              <div className="bg-red-600 p-6 text-white">
                <div className="flex items-center space-x-4">
                  <div className="bg-white text-red-600 rounded-full w-12 h-12 flex items-center justify-center font-bold text-lg">
                    {userData?.name?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <h2 className="font-semibold text-lg">{userData?.name || 'User'}</h2>
                    <p className="text-red-100 text-sm">Donor</p>
                  </div>
                </div>
              </div>

              {/* Blood info */}
              <div className="p-6 border-b">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-gray-500 text-sm">Blood Type</p>
                    <p className="text-2xl font-bold text-red-600">{userData?.bloodType || 'A+'}</p>
                  </div>
                  <div className="bg-red-50 p-3 rounded-full">
                    <DropletHalf className="text-red-600" size={24} />
                  </div>
                </div>
              </div>

              {/* Navigation */}
              <nav className="p-4">
                <ul className="space-y-2">
                  <li>
                    <button 
                      onClick={() => setActiveTab('overview')} 
                      className={`nav-item ${activeTab === 'overview' ? 'bg-red-50 text-red-600' : ''}`}
                    >
                      <Award size={20} />
                      <span>Overview</span>
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => setActiveTab('donations')} 
                      className={`nav-item ${activeTab === 'donations' ? 'bg-red-50 text-red-600' : ''}`}
                    >
                      <DropletHalf size={20} />
                      <span>My Donations</span>
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => setActiveTab('requests')} 
                      className={`nav-item ${activeTab === 'requests' ? 'bg-red-50 text-red-600' : ''}`}
                    >
                      <Bell size={20} />
                      <span>Nearby Requests</span>
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => setActiveTab('schedule')} 
                      className={`nav-item ${activeTab === 'schedule' ? 'bg-red-50 text-red-600' : ''}`}
                    >
                      <Calendar size={20} />
                      <span>Schedule Donation</span>
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={() => setActiveTab('settings')} 
                      className={`nav-item ${activeTab === 'settings' ? 'bg-red-50 text-red-600' : ''}`}
                    >
                      <Settings size={20} />
                      <span>Settings</span>
                    </button>
                  </li>
                  <li>
                    <button 
                      onClick={logout} 
                      className="nav-item text-gray-700 hover:bg-gray-100"
                    >
                      <LogOut size={20} />
                      <span>Logout</span>
                    </button>
                  </li>
                </ul>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Stats Row */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-gray-500 font-medium">Total Donations</h3>
                      <DropletHalf className="text-red-500" size={20} />
                    </div>
                    <p className="text-3xl font-bold">{donations.length}</p>
                    <p className="text-sm text-gray-500 mt-2">Lifetime donations</p>
                  </div>
                  
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-gray-500 font-medium">Lives Saved</h3>
                      <Award className="text-red-500" size={20} />
                    </div>
                    <p className="text-3xl font-bold">{donations.length * 3}</p>
                    <p className="text-sm text-gray-500 mt-2">Each donation saves 3 lives</p>
                  </div>
                  
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-gray-500 font-medium">Next Eligible</h3>
                      <Calendar className="text-red-500" size={20} />
                    </div>
                    <p className="text-xl font-bold">{nextEligibleFormatted}</p>
                    <p className="text-sm text-gray-500 mt-2">3 months since last donation</p>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h2 className="text-xl font-semibold mb-6">Recent Activity</h2>
                  
                  <div className="space-y-4">
                    <div className="flex items-start p-4 bg-gray-50 rounded-lg">
                      <div className="bg-green-100 p-2 rounded-full mr-4">
                        <DropletHalf className="text-green-600" size={20} />
                      </div>
                      <div>
                        <h3 className="font-medium">Donation Completed</h3>
                        <p className="text-gray-600 text-sm">{donations[0]?.location}</p>
                        <p className="text-gray-500 text-xs mt-1">{donations[0]?.date}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start p-4 bg-gray-50 rounded-lg">
                      <div className="bg-blue-100 p-2 rounded-full mr-4">
                        <Award className="text-blue-600" size={20} />
                      </div>
                      <div>
                        <h3 className="font-medium">Achievement Unlocked</h3>
                        <p className="text-gray-600 text-sm">Regular Donor - 3 donations completed</p>
                        <p className="text-gray-500 text-xs mt-1">2 months ago</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Nearby Requests */}
                <div className="bg-white rounded-lg shadow-md p-6">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-semibold">Nearby Blood Requests</h2>
                    <button className="text-red-600 text-sm font-medium hover:underline">
                      View All
                    </button>
                  </div>
                  
                  <div className="space-y-4">
                    {nearbyRequests.slice(0, 2).map(request => (
                      <div key={request.id} className="border rounded-lg p-4 flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="bg-red-100 text-red-600 font-bold rounded-full w-12 h-12 flex items-center justify-center mr-4">
                            {request.bloodType}
                          </div>
                          <div>
                            <h3 className="font-medium">{request.hospital}</h3>
                            <div className="flex items-center text-gray-500 text-sm">
                              <MapPin size={14} className="mr-1" />
                              <span>{request.city}</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`
                            text-xs font-medium px-2 py-1 rounded-full inline-flex items-center
                            ${request.urgency === 'High' ? 'bg-red-100 text-red-600' : 
                              request.urgency === 'Medium' ? 'bg-yellow-100 text-yellow-600' : 
                              'bg-green-100 text-green-600'
                            }
                          `}>
                            <Clock size={12} className="mr-1" />
                            {request.urgency}
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{request.postedOn}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'donations' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-6">My Donation History</h2>
                
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Date</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Location</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Blood Type</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Units</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {donations.map(donation => (
                        <tr key={donation.id}>
                          <td className="px-4 py-4 text-sm text-gray-900">{donation.date}</td>
                          <td className="px-4 py-4 text-sm text-gray-900">{donation.location}</td>
                          <td className="px-4 py-4 text-sm text-gray-900">
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                              {donation.bloodType}
                            </span>
                          </td>
                          <td className="px-4 py-4 text-sm text-gray-900">{donation.units}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                {donations.length === 0 && (
                  <div className="text-center py-12">
                    <DropletHalf className="mx-auto text-gray-300" size={48} />
                    <p className="mt-4 text-gray-500">You haven't made any donations yet.</p>
                    <button className="mt-4 btn-primary">Schedule Your First Donation</button>
                  </div>
                )}
              </div>
            )}
            
            {activeTab === 'requests' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-6">Nearby Blood Requests</h2>
                
                <div className="space-y-4">
                  {nearbyRequests.map(request => (
                    <div key={request.id} className="border rounded-lg p-4">
                      <div className="flex justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="bg-red-100 text-red-600 font-bold rounded-full w-12 h-12 flex items-center justify-center">
                            {request.bloodType}
                          </div>
                          <div>
                            <h3 className="font-medium">{request.hospital}</h3>
                            <div className="flex items-center text-gray-500 text-sm">
                              <MapPin size={14} className="mr-1" />
                              <span>{request.city}</span>
                            </div>
                          </div>
                        </div>
                        <div className={`
                          h-min text-xs font-medium px-2 py-1 rounded-full inline-flex items-center
                          ${request.urgency === 'High' ? 'bg-red-100 text-red-600' : 
                            request.urgency === 'Medium' ? 'bg-yellow-100 text-yellow-600' : 
                            'bg-green-100 text-green-600'
                          }
                        `}>
                          <Clock size={12} className="mr-1" />
                          {request.urgency}
                        </div>
                      </div>
                      
                      <div className="mt-4 flex justify-between items-center">
                        <p className="text-sm text-gray-500">Posted {request.postedOn}</p>
                        <button className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors">
                          Respond
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {activeTab === 'schedule' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-6">Schedule a Donation</h2>
                
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                  <div className="flex items-start">
                    <div className="mt-1 mr-3 text-blue-500">
                      <Clock size={20} />
                    </div>
                    <div>
                      <h3 className="font-medium text-blue-700">Next Eligible Donation Date</h3>
                      <p className="text-blue-600">{nextEligibleFormatted}</p>
                      <p className="text-sm text-blue-500 mt-1">
                        You need to wait at least 3 months between whole blood donations.
                      </p>
                    </div>
                  </div>
                </div>
                
                <form>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label htmlFor="donation-date" className="form-label">Preferred Date</label>
                      <input 
                        type="date" 
                        id="donation-date" 
                        className="form-input" 
                        min={nextEligibleFormatted}
                      />
                    </div>
                    <div>
                      <label htmlFor="donation-time" className="form-label">Preferred Time</label>
                      <select id="donation-time" className="form-select">
                        <option value="">Select a time slot</option>
                        <option value="09:00">09:00 AM - 10:00 AM</option>
                        <option value="10:00">10:00 AM - 11:00 AM</option>
                        <option value="11:00">11:00 AM - 12:00 PM</option>
                        <option value="14:00">02:00 PM - 03:00 PM</option>
                        <option value="15:00">03:00 PM - 04:00 PM</option>
                        <option value="16:00">04:00 PM - 05:00 PM</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <label htmlFor="donation-center" className="form-label">Blood Donation Center</label>
                    <select id="donation-center" className="form-select">
                      <option value="">Select a center</option>
                      <option value="1">Red Cross Blood Bank - Pune</option>
                      <option value="2">Civil Hospital Blood Bank - Pune</option>
                      <option value="3">Army Medical Corps Blood Centre - Pune</option>
                      <option value="4">Sahyadri Hospital Blood Bank - Pune</option>
                    </select>
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="donation-notes" className="form-label">Special Notes</label>
                    <textarea 
                      id="donation-notes" 
                      className="form-textarea" 
                      rows={3}
                      placeholder="Any health conditions or special requirements..."
                    ></textarea>
                  </div>
                  
                  <button type="submit" className="btn-primary">
                    Schedule Appointment
                  </button>
                </form>
              </div>
            )}
            
            {activeTab === 'settings' && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-6">Settings</h2>
                
                <div className="space-y-6">
                  {/* Profile Settings */}
                  <div>
                    <h3 className="text-lg font-medium mb-4">Profile Information</h3>
                    <form className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="settings-name" className="form-label">Full Name</label>
                          <input 
                            type="text" 
                            id="settings-name" 
                            className="form-input" 
                            defaultValue={userData?.name}
                          />
                        </div>
                        <div>
                          <label htmlFor="settings-email" className="form-label">Email Address</label>
                          <input 
                            type="email" 
                            id="settings-email" 
                            className="form-input" 
                            defaultValue={userData?.email}
                          />
                        </div>
                        <div>
                          <label htmlFor="settings-phone" className="form-label">Phone Number</label>
                          <input 
                            type="tel" 
                            id="settings-phone" 
                            className="form-input" 
                            defaultValue={userData?.phone}
                          />
                        </div>
                        <div>
                          <label htmlFor="settings-blood-type" className="form-label">Blood Type</label>
                          <select 
                            id="settings-blood-type" 
                            className="form-select"
                            defaultValue={userData?.bloodType}
                          >
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                          </select>
                        </div>
                      </div>
                      
                      <button type="submit" className="btn-primary">
                        Update Profile
                      </button>
                    </form>
                  </div>
                  
                  {/* Location Settings */}
                  <div className="pt-6 border-t">
                    <h3 className="text-lg font-medium mb-4">Location Information</h3>
                    <form className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label htmlFor="settings-state" className="form-label">State</label>
                          <select 
                            id="settings-state" 
                            className="form-select"
                            defaultValue={userData?.state}
                          >
                            <option value="Maharashtra">Maharashtra</option>
                            <option value="Delhi">Delhi</option>
                            <option value="Karnataka">Karnataka</option>
                            <option value="Tamil Nadu">Tamil Nadu</option>
                            <option value="Gujarat">Gujarat</option>
                          </select>
                        </div>
                        <div>
                          <label htmlFor="settings-city" className="form-label">City</label>
                          <input 
                            type="text" 
                            id="settings-city" 
                            className="form-input" 
                            defaultValue={userData?.city}
                          />
                        </div>
                        <div>
                          <label htmlFor="settings-pincode" className="form-label">Pincode</label>
                          <input 
                            type="text" 
                            id="settings-pincode" 
                            className="form-input" 
                            defaultValue={userData?.pincode}
                          />
                        </div>
                      </div>
                      
                      <button type="submit" className="btn-primary">
                        Update Location
                      </button>
                    </form>
                  </div>
                  
                  {/* Password Settings */}
                  <div className="pt-6 border-t">
                    <h3 className="text-lg font-medium mb-4">Change Password</h3>
                    <form className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label htmlFor="current-password" className="form-label">Current Password</label>
                          <input 
                            type="password" 
                            id="current-password" 
                            className="form-input" 
                          />
                        </div>
                        <div>
                          <label htmlFor="new-password" className="form-label">New Password</label>
                          <input 
                            type="password" 
                            id="new-password" 
                            className="form-input" 
                          />
                        </div>
                        <div>
                          <label htmlFor="confirm-password" className="form-label">Confirm Password</label>
                          <input 
                            type="password" 
                            id="confirm-password" 
                            className="form-input" 
                          />
                        </div>
                      </div>
                      
                      <button type="submit" className="btn-primary">
                        Update Password
                      </button>
                    </form>
                  </div>
                  
                  {/* Notification Settings */}
                  <div className="pt-6 border-t">
                    <h3 className="text-lg font-medium mb-4">Notification Settings</h3>
                    <form>
                      <div className="space-y-3">
                        <label className="flex items-center">
                          <input type="checkbox" className="form-checkbox" defaultChecked />
                          <span className="ml-2">Email notifications for nearby blood requests</span>
                        </label>
                        <label className="flex items-center">
                          <input type="checkbox" className="form-checkbox" defaultChecked />
                          <span className="ml-2">SMS alerts for emergency blood requests</span>
                        </label>
                        <label className="flex items-center">
                          <input type="checkbox" className="form-checkbox" defaultChecked />
                          <span className="ml-2">Donation reminders</span>
                        </label>
                        <label className="flex items-center">
                          <input type="checkbox" className="form-checkbox" />
                          <span className="ml-2">Monthly newsletter</span>
                        </label>
                      </div>
                      
                      <button type="submit" className="btn-primary mt-4">
                        Update Notifications
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DonorDashboard;