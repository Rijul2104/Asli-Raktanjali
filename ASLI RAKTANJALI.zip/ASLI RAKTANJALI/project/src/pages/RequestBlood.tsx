import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, Guitar as Hospital, Clock, AlertTriangle, Droplet as DropletHalf } from 'lucide-react';
import { states } from '../data/states';

const RequestBlood: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    patientName: '',
    patientAge: '',
    patientGender: '',
    bloodType: '',
    units: '1',
    hospital: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    requiredDate: '',
    urgency: 'medium',
    medicalCondition: '',
    contactName: '',
    contactPhone: '',
    alternatePhone: '',
    contactEmail: '',
    additionalNotes: '',
    agreeToTerms: false,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    });

    // Clear error for this field when user starts typing
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: '',
      });
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.patientName) newErrors.patientName = 'Patient name is required';
    if (!formData.patientAge) newErrors.patientAge = 'Patient age is required';
    if (!formData.patientGender) newErrors.patientGender = 'Patient gender is required';
    if (!formData.bloodType) newErrors.bloodType = 'Blood type is required';
    if (!formData.hospital) newErrors.hospital = 'Hospital name is required';
    if (!formData.city) newErrors.city = 'City is required';
    if (!formData.state) newErrors.state = 'State is required';
    if (!formData.pincode) {
      newErrors.pincode = 'Pincode is required';
    } else if (!/^\d{6}$/.test(formData.pincode)) {
      newErrors.pincode = 'Pincode must be 6 digits';
    }
    
    if (!formData.requiredDate) newErrors.requiredDate = 'Required date is required';
    
    if (!formData.contactName) newErrors.contactName = 'Contact name is required';
    if (!formData.contactPhone) {
      newErrors.contactPhone = 'Contact phone is required';
    } else if (!/^\d{10}$/.test(formData.contactPhone)) {
      newErrors.contactPhone = 'Phone must be 10 digits';
    }
    
    if (formData.alternatePhone && !/^\d{10}$/.test(formData.alternatePhone)) {
      newErrors.alternatePhone = 'Phone must be 10 digits';
    }
    
    if (!formData.contactEmail) {
      newErrors.contactEmail = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.contactEmail)) {
      newErrors.contactEmail = 'Email is invalid';
    }
    
    if (!formData.agreeToTerms) {
      newErrors.agreeToTerms = 'You must agree to the terms';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      // Scroll to the first error
      const firstErrorField = Object.keys(errors)[0];
      const element = document.getElementById(firstErrorField);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }
    
    // Submit the form (in a real app, this would connect to a backend)
    console.log('Form submitted with data:', formData);
    
    // Redirect to recipient dashboard or confirmation page
    navigate('/recipient-dashboard');
  };

  const urgencyLabels = {
    low: 'Low - Within a week',
    medium: 'Medium - Within 2-3 days',
    high: 'High - Within 24 hours',
    critical: 'Critical - Immediate',
  };

  const bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h1 className="text-3xl md:text-4xl font-bold font-serif text-gray-800 mb-4">
              Request Blood
            </h1>
            <p className="text-lg text-gray-600">
              Fill out the form below to create a blood request. Please provide accurate information
              to help donors respond to your need.
            </p>
          </div>

          {/* Important Information Box */}
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-5 mb-8 rounded-r-md">
            <div className="flex">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-5 w-5 text-yellow-400" />
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-medium text-yellow-800">Important Information</h3>
                <div className="mt-2 text-yellow-700">
                  <p>
                    Only create blood requests for genuine medical needs. All requests are verified before being published. 
                    Provide accurate hospital and contact information to ensure a smooth donation process.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Request Form */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-8">
              <form onSubmit={handleSubmit} className="space-y-8">
                {/* Patient Information */}
                <div>
                  <h2 className="text-xl font-semibold mb-4 flex items-center">
                    <Hospital className="mr-2 text-red-600" size={20} />
                    Patient Information
                  </h2>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="patientName" className="form-label">
                        Patient Name
                      </label>
                      <input
                        type="text"
                        id="patientName"
                        name="patientName"
                        className={`form-input ${errors.patientName ? 'border-red-500' : ''}`}
                        value={formData.patientName}
                        onChange={handleInputChange}
                        placeholder="Full name of the patient"
                      />
                      {errors.patientName && (
                        <p className="error-message">{errors.patientName}</p>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="patientAge" className="form-label">
                          Age
                        </label>
                        <input
                          type="number"
                          id="patientAge"
                          name="patientAge"
                          className={`form-input ${errors.patientAge ? 'border-red-500' : ''}`}
                          value={formData.patientAge}
                          onChange={handleInputChange}
                          placeholder="Age in years"
                          min="0"
                          max="120"
                        />
                        {errors.patientAge && (
                          <p className="error-message">{errors.patientAge}</p>
                        )}
                      </div>

                      <div>
                        <label htmlFor="patientGender" className="form-label">
                          Gender
                        </label>
                        <select
                          id="patientGender"
                          name="patientGender"
                          className={`form-select ${errors.patientGender ? 'border-red-500' : ''}`}
                          value={formData.patientGender}
                          onChange={handleInputChange}
                        >
                          <option value="">Select</option>
                          <option value="male">Male</option>
                          <option value="female">Female</option>
                          <option value="other">Other</option>
                        </select>
                        {errors.patientGender && (
                          <p className="error-message">{errors.patientGender}</p>
                        )}
                      </div>
                    </div>

                    <div>
                      <label htmlFor="medicalCondition" className="form-label">
                        Medical Condition
                      </label>
                      <textarea
                        id="medicalCondition"
                        name="medicalCondition"
                        rows={3}
                        className="form-textarea"
                        value={formData.medicalCondition}
                        onChange={handleInputChange}
                        placeholder="Brief description of medical condition (optional)"
                      ></textarea>
                    </div>
                  </div>
                </div>

                {/* Blood Requirement */}
                <div className="pt-6 border-t">
                  <h2 className="text-xl font-semibold mb-4 flex items-center">
                    <DropletHalf className="mr-2 text-red-600" size={20} />
                    Blood Requirement
                  </h2>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <label htmlFor="bloodType" className="form-label">
                        Blood Type Needed
                      </label>
                      <select
                        id="bloodType"
                        name="bloodType"
                        className={`form-select ${errors.bloodType ? 'border-red-500' : ''}`}
                        value={formData.bloodType}
                        onChange={handleInputChange}
                      >
                        <option value="">Select Blood Type</option>
                        {bloodTypes.map(type => (
                          <option key={type} value={type}>
                            {type}
                          </option>
                        ))}
                      </select>
                      {errors.bloodType && (
                        <p className="error-message">{errors.bloodType}</p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="units" className="form-label">
                        Units Required
                      </label>
                      <select
                        id="units"
                        name="units"
                        className="form-select"
                        value={formData.units}
                        onChange={handleInputChange}
                      >
                        <option value="1">1 unit</option>
                        <option value="2">2 units</option>
                        <option value="3">3 units</option>
                        <option value="4">4 units</option>
                        <option value="5+">5+ units</option>
                      </select>
                    </div>

                    <div>
                      <label htmlFor="urgency" className="form-label">
                        Urgency Level
                      </label>
                      <select
                        id="urgency"
                        name="urgency"
                        className="form-select"
                        value={formData.urgency}
                        onChange={handleInputChange}
                      >
                        {Object.entries(urgencyLabels).map(([value, label]) => (
                          <option key={value} value={value}>
                            {label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label htmlFor="requiredDate" className="form-label">
                        Required By Date
                      </label>
                      <input
                        type="date"
                        id="requiredDate"
                        name="requiredDate"
                        className={`form-input ${errors.requiredDate ? 'border-red-500' : ''}`}
                        value={formData.requiredDate}
                        onChange={handleInputChange}
                        min={new Date().toISOString().split('T')[0]}
                      />
                      {errors.requiredDate && (
                        <p className="error-message">{errors.requiredDate}</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Hospital Information */}
                <div className="pt-6 border-t">
                  <h2 className="text-xl font-semibold mb-4 flex items-center">
                    <Hospital className="mr-2 text-red-600" size={20} />
                    Hospital Information
                  </h2>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="hospital" className="form-label">
                        Hospital Name
                      </label>
                      <input
                        type="text"
                        id="hospital"
                        name="hospital"
                        className={`form-input ${errors.hospital ? 'border-red-500' : ''}`}
                        value={formData.hospital}
                        onChange={handleInputChange}
                        placeholder="Name of the hospital"
                      />
                      {errors.hospital && (
                        <p className="error-message">{errors.hospital}</p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="address" className="form-label">
                        Hospital Address
                      </label>
                      <input
                        type="text"
                        id="address"
                        name="address"
                        className="form-input"
                        value={formData.address}
                        onChange={handleInputChange}
                        placeholder="Street address"
                      />
                    </div>

                    <div>
                      <label htmlFor="state" className="form-label">
                        State
                      </label>
                      <select
                        id="state"
                        name="state"
                        className={`form-select ${errors.state ? 'border-red-500' : ''}`}
                        value={formData.state}
                        onChange={handleInputChange}
                      >
                        <option value="">Select State</option>
                        {states.map((state) => (
                          <option key={state} value={state}>
                            {state}
                          </option>
                        ))}
                      </select>
                      {errors.state && <p className="error-message">{errors.state}</p>}
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="city" className="form-label">
                          City
                        </label>
                        <input
                          type="text"
                          id="city"
                          name="city"
                          className={`form-input ${errors.city ? 'border-red-500' : ''}`}
                          value={formData.city}
                          onChange={handleInputChange}
                          placeholder="City"
                        />
                        {errors.city && <p className="error-message">{errors.city}</p>}
                      </div>

                      <div>
                        <label htmlFor="pincode" className="form-label">
                          Pincode
                        </label>
                        <input
                          type="text"
                          id="pincode"
                          name="pincode"
                          className={`form-input ${errors.pincode ? 'border-red-500' : ''}`}
                          value={formData.pincode}
                          onChange={handleInputChange}
                          placeholder="6-digit pincode"
                          maxLength={6}
                        />
                        {errors.pincode && (
                          <p className="error-message">{errors.pincode}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Contact Information */}
                <div className="pt-6 border-t">
                  <h2 className="text-xl font-semibold mb-4 flex items-center">
                    <Bell className="mr-2 text-red-600" size={20} />
                    Contact Information
                  </h2>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="contactName" className="form-label">
                        Contact Person
                      </label>
                      <input
                        type="text"
                        id="contactName"
                        name="contactName"
                        className={`form-input ${errors.contactName ? 'border-red-500' : ''}`}
                        value={formData.contactName}
                        onChange={handleInputChange}
                        placeholder="Name of primary contact person"
                      />
                      {errors.contactName && (
                        <p className="error-message">{errors.contactName}</p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="contactPhone" className="form-label">
                        Contact Phone
                      </label>
                      <input
                        type="tel"
                        id="contactPhone"
                        name="contactPhone"
                        className={`form-input ${errors.contactPhone ? 'border-red-500' : ''}`}
                        value={formData.contactPhone}
                        onChange={handleInputChange}
                        placeholder="10-digit mobile number"
                        maxLength={10}
                      />
                      {errors.contactPhone && (
                        <p className="error-message">{errors.contactPhone}</p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="alternatePhone" className="form-label">
                        Alternate Phone (Optional)
                      </label>
                      <input
                        type="tel"
                        id="alternatePhone"
                        name="alternatePhone"
                        className={`form-input ${errors.alternatePhone ? 'border-red-500' : ''}`}
                        value={formData.alternatePhone}
                        onChange={handleInputChange}
                        placeholder="Alternate 10-digit mobile number"
                        maxLength={10}
                      />
                      {errors.alternatePhone && (
                        <p className="error-message">{errors.alternatePhone}</p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="contactEmail" className="form-label">
                        Email Address
                      </label>
                      <input
                        type="email"
                        id="contactEmail"
                        name="contactEmail"
                        className={`form-input ${errors.contactEmail ? 'border-red-500' : ''}`}
                        value={formData.contactEmail}
                        onChange={handleInputChange}
                        placeholder="Email address for notifications"
                      />
                      {errors.contactEmail && (
                        <p className="error-message">{errors.contactEmail}</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Additional Notes */}
                <div>
                  <label htmlFor="additionalNotes" className="form-label">
                    Additional Notes (Optional)
                  </label>
                  <textarea
                    id="additionalNotes"
                    name="additionalNotes"
                    rows={3}
                    className="form-textarea"
                    value={formData.additionalNotes}
                    onChange={handleInputChange}
                    placeholder="Any additional information for donors..."
                  ></textarea>
                </div>

                {/* Terms and Submit */}
                <div className="pt-6 border-t">
                  <div className="mb-6">
                    <label className="flex items-start">
                      <input
                        type="checkbox"
                        name="agreeToTerms"
                        className="mt-1 mr-2"
                        checked={formData.agreeToTerms}
                        onChange={handleInputChange}
                      />
                      <span className="text-sm text-gray-600">
                        I confirm that this request is for a genuine medical need and all
                        information provided is accurate. I agree to Raktanjali's{' '}
                        <a href="#" className="text-red-600 hover:underline">
                          Terms of Service
                        </a>{' '}
                        and{' '}
                        <a href="#" className="text-red-600 hover:underline">
                          Privacy Policy
                        </a>
                        .
                      </span>
                    </label>
                    {errors.agreeToTerms && (
                      <p className="error-message">{errors.agreeToTerms}</p>
                    )}
                  </div>

                  <div className="flex justify-center">
                    <button
                      type="submit"
                      className="btn-primary w-full md:w-auto md:px-12 flex items-center justify-center"
                    >
                      <Bell size={18} className="mr-2" />
                      Submit Blood Request
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequestBlood;